//conecting my buttons from css to javascript//
button.id = "button";
 button.id = ".button1";
 button.id = ".btn2";
 button.id = ".btn3";
//conecting my images from css to javascript//
 img.id = ".img2";
 img.id = ".img3";
 img.id = ".img4";
 img.id = ".img5";
 nav.id = "nav";